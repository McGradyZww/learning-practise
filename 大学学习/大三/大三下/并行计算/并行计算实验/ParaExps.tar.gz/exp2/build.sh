mpicc ./main.cpp -o exp2 -lstdc++

