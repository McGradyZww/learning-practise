mpirun -n $1 ./exp2 $2

