mpirun -n $1 ./exp5 $2 $3

