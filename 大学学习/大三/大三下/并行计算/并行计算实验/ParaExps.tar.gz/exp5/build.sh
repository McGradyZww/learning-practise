mpicc ./main.cpp -o exp5 -lstdc++

