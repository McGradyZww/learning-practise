gcc ./main.cpp -o exp3 -fopenmp -lstdc++

