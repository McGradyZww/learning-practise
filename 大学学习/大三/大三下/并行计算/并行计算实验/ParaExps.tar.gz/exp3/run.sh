export OMP_NUM_THREADS=3
./exp3 $1

