mpirun -n $1 ./exp1

