mpicc ./main.cpp -o exp1 -lstdc++ -O2

