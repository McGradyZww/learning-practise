mpicc ./main.cpp -o exp4 -fopenmp -lstdc++

