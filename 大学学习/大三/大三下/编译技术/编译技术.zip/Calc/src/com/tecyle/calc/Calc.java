package com.tecyle.calc;
import org.antlr.runtime.*;
import org.antlr.runtime.tree.CommonTree;
import org.antlr.runtime.tree.CommonTreeNodeStream;
import org.antlr.runtime.tree.TreeNodeStream;

public class Calc {
	/**
	* @param args
	*/
	public static void main(String[] args)throws Exception
	{
		// TODO Auto-generated method stub
		ANTLRInputStream input = new ANTLRInputStream(System.in);
		CalcLexer lex = new CalcLexer(input);
		CommonTokenStream tokens = new CommonTokenStream(lex);
		CalcParser parser = new CalcParser(tokens);
		CalcParser.program_return r = parser.program();
		CommonTree tree = r.tree;
		CommonTreeNodeStream treeStream = new	CommonTreeNodeStream(tree);
		CalcTree walker = new CalcTree(treeStream);
		try
		{
			walker.program();
		}
		catch (Exception e)
		{
		e.printStackTrace();
		}
	}

}
