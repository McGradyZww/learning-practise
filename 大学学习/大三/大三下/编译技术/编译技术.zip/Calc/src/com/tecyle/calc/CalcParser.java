// $ANTLR 3.5 D:\\���뼼��\\antlr\\Calc.g 2013-03-26 15:15:33
package com.tecyle.calc;

import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

import org.antlr.runtime.tree.*;


@SuppressWarnings("all")
public class CalcParser extends Parser {
	public static final String[] tokenNames = new String[] {
		"<invalid>", "<EOR>", "<DOWN>", "<UP>", "DOUBLE", "ID", "SEMI", "WS", 
		"'('", "')'", "'*'", "'+'", "','", "'-'", "'/'", "'='", "'^'", "'cos'", 
		"'ln'", "'log'", "'sin'", "'tan'"
	};
	public static final int EOF=-1;
	public static final int T__8=8;
	public static final int T__9=9;
	public static final int T__10=10;
	public static final int T__11=11;
	public static final int T__12=12;
	public static final int T__13=13;
	public static final int T__14=14;
	public static final int T__15=15;
	public static final int T__16=16;
	public static final int T__17=17;
	public static final int T__18=18;
	public static final int T__19=19;
	public static final int T__20=20;
	public static final int T__21=21;
	public static final int DOUBLE=4;
	public static final int ID=5;
	public static final int SEMI=6;
	public static final int WS=7;

	// delegates
	public Parser[] getDelegates() {
		return new Parser[] {};
	}

	// delegators


	public CalcParser(TokenStream input) {
		this(input, new RecognizerSharedState());
	}
	public CalcParser(TokenStream input, RecognizerSharedState state) {
		super(input, state);
	}

	protected TreeAdaptor adaptor = new CommonTreeAdaptor();

	public void setTreeAdaptor(TreeAdaptor adaptor) {
		this.adaptor = adaptor;
	}
	public TreeAdaptor getTreeAdaptor() {
		return adaptor;
	}
	@Override public String[] getTokenNames() { return CalcParser.tokenNames; }
	@Override public String getGrammarFileName() { return "D:\\���뼼��\\antlr\\Calc.g"; }


	public static class program_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "program"
	// D:\\���뼼��\\antlr\\Calc.g:9:1: program : ( statement )+ ;
	public final CalcParser.program_return program()  {
		CalcParser.program_return retval = new CalcParser.program_return();
		retval.start = input.LT(1);

		CommonTree root_0 = null;

		ParserRuleReturnScope statement1 =null;


		try {
			// D:\\���뼼��\\antlr\\Calc.g:9:9: ( ( statement )+ )
			// D:\\���뼼��\\antlr\\Calc.g:9:11: ( statement )+
			{
			root_0 = (CommonTree)adaptor.nil();


			// D:\\���뼼��\\antlr\\Calc.g:9:11: ( statement )+
			int cnt1=0;
			loop1:
			while (true) {
				int alt1=2;
				int LA1_0 = input.LA(1);
				if ( ((LA1_0 >= DOUBLE && LA1_0 <= SEMI)||LA1_0==8||LA1_0==13||(LA1_0 >= 17 && LA1_0 <= 21)) ) {
					alt1=1;
				}

				switch (alt1) {
				case 1 :
					// D:\\���뼼��\\antlr\\Calc.g:9:12: statement
					{
					pushFollow(FOLLOW_statement_in_program40);
					statement1=statement();
					state._fsp--;

					adaptor.addChild(root_0, statement1.getTree());

					System.out.println((statement1!=null?((CommonTree)statement1.getTree()):null).toStringTree());
					}
					break;

				default :
					if ( cnt1 >= 1 ) break loop1;
					EarlyExitException eee = new EarlyExitException(1, input);
					throw eee;
				}
				cnt1++;
			}

			}

			retval.stop = input.LT(-1);

			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "program"


	public static class statement_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "statement"
	// D:\\���뼼��\\antlr\\Calc.g:10:1: statement : ( expression SEMI -> expression | ID '=' expression SEMI -> ^( '=' ID expression ) | SEMI ->);
	public final CalcParser.statement_return statement()   {
		CalcParser.statement_return retval = new CalcParser.statement_return();
		retval.start = input.LT(1);

		CommonTree root_0 = null;

		Token SEMI3=null;
		Token ID4=null;
		Token char_literal5=null;
		Token SEMI7=null;
		Token SEMI8=null;
		ParserRuleReturnScope expression2 =null;
		ParserRuleReturnScope expression6 =null;

		CommonTree SEMI3_tree=null;
		CommonTree ID4_tree=null;
		CommonTree char_literal5_tree=null;
		CommonTree SEMI7_tree=null;
		CommonTree SEMI8_tree=null;
		RewriteRuleTokenStream stream_ID=new RewriteRuleTokenStream(adaptor,"token ID");
		RewriteRuleTokenStream stream_15=new RewriteRuleTokenStream(adaptor,"token 15");
		RewriteRuleTokenStream stream_SEMI=new RewriteRuleTokenStream(adaptor,"token SEMI");
		RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");

		try {
			// D:\\���뼼��\\antlr\\Calc.g:11:3: ( expression SEMI -> expression | ID '=' expression SEMI -> ^( '=' ID expression ) | SEMI ->)
			int alt2=3;
			switch ( input.LA(1) ) {
			case DOUBLE:
			case 8:
			case 13:
			case 17:
			case 18:
			case 19:
			case 20:
			case 21:
				{
				alt2=1;
				}
				break;
			case ID:
				{
				int LA2_2 = input.LA(2);
				if ( (LA2_2==15) ) {
					alt2=2;
				}
				else if ( (LA2_2==SEMI||(LA2_2 >= 10 && LA2_2 <= 11)||(LA2_2 >= 13 && LA2_2 <= 14)||LA2_2==16) ) {
					alt2=1;
				}

				else {
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 2, 2, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case SEMI:
				{
				alt2=3;
				}
				break;
			default:
				NoViableAltException nvae =
					new NoViableAltException("", 2, 0, input);
				throw nvae;
			}
			switch (alt2) {
				case 1 :
					// D:\\���뼼��\\antlr\\Calc.g:11:3: expression SEMI
					{
					pushFollow(FOLLOW_expression_in_statement53);
					expression2=expression();
					state._fsp--;

					stream_expression.add(expression2.getTree());
					SEMI3=(Token)match(input,SEMI,FOLLOW_SEMI_in_statement55);  
					stream_SEMI.add(SEMI3);

					// AST REWRITE
					// elements: expression
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 11:19: -> expression
					{
						adaptor.addChild(root_0, stream_expression.nextTree());
					}


					retval.tree = root_0;

					}
					break;
				case 2 :
					// D:\\���뼼��\\antlr\\Calc.g:12:3: ID '=' expression SEMI
					{
					ID4=(Token)match(input,ID,FOLLOW_ID_in_statement63);  
					stream_ID.add(ID4);

					char_literal5=(Token)match(input,15,FOLLOW_15_in_statement65);  
					stream_15.add(char_literal5);

					pushFollow(FOLLOW_expression_in_statement67);
					expression6=expression();
					state._fsp--;

					stream_expression.add(expression6.getTree());
					SEMI7=(Token)match(input,SEMI,FOLLOW_SEMI_in_statement69);  
					stream_SEMI.add(SEMI7);

					// AST REWRITE
					// elements: ID, 15, expression
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 12:26: -> ^( '=' ID expression )
					{
						// D:\\���뼼��\\antlr\\Calc.g:12:29: ^( '=' ID expression )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot(stream_15.nextNode(), root_1);
						adaptor.addChild(root_1, stream_ID.nextNode());
						adaptor.addChild(root_1, stream_expression.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;

					}
					break;
				case 3 :
					// D:\\���뼼��\\antlr\\Calc.g:13:3: SEMI
					{
					SEMI8=(Token)match(input,SEMI,FOLLOW_SEMI_in_statement83);  
					stream_SEMI.add(SEMI8);

					// AST REWRITE
					// elements: 
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 13:8: ->
					{
						root_0 = null;
					}


					retval.tree = root_0;

					}
					break;

			}
			retval.stop = input.LT(-1);

			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "statement"


	public static class expression_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "expression"
	// D:\\���뼼��\\antlr\\Calc.g:15:1: expression : term ( ( '+' ^| '-' ^) term )* ;
	public final CalcParser.expression_return expression()   {
		CalcParser.expression_return retval = new CalcParser.expression_return();
		retval.start = input.LT(1);

		CommonTree root_0 = null;

		Token char_literal10=null;
		Token char_literal11=null;
		ParserRuleReturnScope term9 =null;
		ParserRuleReturnScope term12 =null;

		CommonTree char_literal10_tree=null;
		CommonTree char_literal11_tree=null;

		try {
			// D:\\���뼼��\\antlr\\Calc.g:16:3: ( term ( ( '+' ^| '-' ^) term )* )
			// D:\\���뼼��\\antlr\\Calc.g:16:3: term ( ( '+' ^| '-' ^) term )*
			{
			root_0 = (CommonTree)adaptor.nil();


			pushFollow(FOLLOW_term_in_expression94);
			term9=term();
			state._fsp--;

			adaptor.addChild(root_0, term9.getTree());

			// D:\\���뼼��\\antlr\\Calc.g:16:8: ( ( '+' ^| '-' ^) term )*
			loop4:
			while (true) {
				int alt4=2;
				int LA4_0 = input.LA(1);
				if ( (LA4_0==11||LA4_0==13) ) {
					alt4=1;
				}

				switch (alt4) {
				case 1 :
					// D:\\���뼼��\\antlr\\Calc.g:16:9: ( '+' ^| '-' ^) term
					{
					// D:\\���뼼��\\antlr\\Calc.g:16:9: ( '+' ^| '-' ^)
					int alt3=2;
					int LA3_0 = input.LA(1);
					if ( (LA3_0==11) ) {
						alt3=1;
					}
					else if ( (LA3_0==13) ) {
						alt3=2;
					}

					else {
						NoViableAltException nvae =
							new NoViableAltException("", 3, 0, input);
						throw nvae;
					}

					switch (alt3) {
						case 1 :
							// D:\\���뼼��\\antlr\\Calc.g:16:10: '+' ^
							{
							char_literal10=(Token)match(input,11,FOLLOW_11_in_expression98); 
							char_literal10_tree = (CommonTree)adaptor.create(char_literal10);
							root_0 = (CommonTree)adaptor.becomeRoot(char_literal10_tree, root_0);

							}
							break;
						case 2 :
							// D:\\���뼼��\\antlr\\Calc.g:16:17: '-' ^
							{
							char_literal11=(Token)match(input,13,FOLLOW_13_in_expression103); 
							char_literal11_tree = (CommonTree)adaptor.create(char_literal11);
							root_0 = (CommonTree)adaptor.becomeRoot(char_literal11_tree, root_0);

							}
							break;

					}

					pushFollow(FOLLOW_term_in_expression107);
					term12=term();
					state._fsp--;

					adaptor.addChild(root_0, term12.getTree());

					}
					break;

				default :
					break loop4;
				}
			}

			}

			retval.stop = input.LT(-1);

			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "expression"


	public static class term_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "term"
	// D:\\���뼼��\\antlr\\Calc.g:17:1: term : factor ( ( '*' ^| '/' ^) factor )* ;
	public final CalcParser.term_return term()   {
		CalcParser.term_return retval = new CalcParser.term_return();
		retval.start = input.LT(1);

		CommonTree root_0 = null;

		Token char_literal14=null;
		Token char_literal15=null;
		ParserRuleReturnScope factor13 =null;
		ParserRuleReturnScope factor16 =null;

		CommonTree char_literal14_tree=null;
		CommonTree char_literal15_tree=null;

		try {
			// D:\\���뼼��\\antlr\\Calc.g:17:6: ( factor ( ( '*' ^| '/' ^) factor )* )
			// D:\\���뼼��\\antlr\\Calc.g:17:8: factor ( ( '*' ^| '/' ^) factor )*
			{
			root_0 = (CommonTree)adaptor.nil();


			pushFollow(FOLLOW_factor_in_term117);
			factor13=factor();
			state._fsp--;

			adaptor.addChild(root_0, factor13.getTree());

			// D:\\���뼼��\\antlr\\Calc.g:17:15: ( ( '*' ^| '/' ^) factor )*
			loop6:
			while (true) {
				int alt6=2;
				int LA6_0 = input.LA(1);
				if ( (LA6_0==10||LA6_0==14) ) {
					alt6=1;
				}

				switch (alt6) {
				case 1 :
					// D:\\���뼼��\\antlr\\Calc.g:17:16: ( '*' ^| '/' ^) factor
					{
					// D:\\���뼼��\\antlr\\Calc.g:17:16: ( '*' ^| '/' ^)
					int alt5=2;
					int LA5_0 = input.LA(1);
					if ( (LA5_0==10) ) {
						alt5=1;
					}
					else if ( (LA5_0==14) ) {
						alt5=2;
					}

					else {
						NoViableAltException nvae =
							new NoViableAltException("", 5, 0, input);
						throw nvae;
					}

					switch (alt5) {
						case 1 :
							// D:\\���뼼��\\antlr\\Calc.g:17:17: '*' ^
							{
							char_literal14=(Token)match(input,10,FOLLOW_10_in_term121); 
							char_literal14_tree = (CommonTree)adaptor.create(char_literal14);
							root_0 = (CommonTree)adaptor.becomeRoot(char_literal14_tree, root_0);

							}
							break;
						case 2 :
							// D:\\���뼼��\\antlr\\Calc.g:17:24: '/' ^
							{
							char_literal15=(Token)match(input,14,FOLLOW_14_in_term126); 
							char_literal15_tree = (CommonTree)adaptor.create(char_literal15);
							root_0 = (CommonTree)adaptor.becomeRoot(char_literal15_tree, root_0);

							}
							break;

					}

					pushFollow(FOLLOW_factor_in_term130);
					factor16=factor();
					state._fsp--;

					adaptor.addChild(root_0, factor16.getTree());

					}
					break;

				default :
					break loop6;
				}
			}

			}

			retval.stop = input.LT(-1);

			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "term"


	public static class factor_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "factor"
	// D:\\���뼼��\\antlr\\Calc.g:18:1: factor : atom ( '^' ^ atom )* ;
	public final CalcParser.factor_return factor()   {
		CalcParser.factor_return retval = new CalcParser.factor_return();
		retval.start = input.LT(1);

		CommonTree root_0 = null;

		Token char_literal18=null;
		ParserRuleReturnScope atom17 =null;
		ParserRuleReturnScope atom19 =null;

		CommonTree char_literal18_tree=null;

		try {
			// D:\\���뼼��\\antlr\\Calc.g:18:8: ( atom ( '^' ^ atom )* )
			// D:\\���뼼��\\antlr\\Calc.g:18:10: atom ( '^' ^ atom )*
			{
			root_0 = (CommonTree)adaptor.nil();


			pushFollow(FOLLOW_atom_in_factor140);
			atom17=atom();
			state._fsp--;

			adaptor.addChild(root_0, atom17.getTree());

			// D:\\���뼼��\\antlr\\Calc.g:18:15: ( '^' ^ atom )*
			loop7:
			while (true) {
				int alt7=2;
				int LA7_0 = input.LA(1);
				if ( (LA7_0==16) ) {
					alt7=1;
				}

				switch (alt7) {
				case 1 :
					// D:\\���뼼��\\antlr\\Calc.g:18:16: '^' ^ atom
					{
					char_literal18=(Token)match(input,16,FOLLOW_16_in_factor143); 
					char_literal18_tree = (CommonTree)adaptor.create(char_literal18);
					root_0 = (CommonTree)adaptor.becomeRoot(char_literal18_tree, root_0);

					pushFollow(FOLLOW_atom_in_factor146);
					atom19=atom();
					state._fsp--;

					adaptor.addChild(root_0, atom19.getTree());

					}
					break;

				default :
					break loop7;
				}
			}

			}

			retval.stop = input.LT(-1);

			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "factor"


	public static class atom_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "atom"
	// D:\\���뼼��\\antlr\\Calc.g:19:1: atom : ( DOUBLE | ID | '(' ! expression ')' !| 'sin' '(' ! expression ')' !| 'cos' '(' ! expression ')' !| 'tan' '(' ! expression ')' !| 'ln' '(' ! expression ')' !| 'log' '(' ! expression ',' ! expression ')' !| '-' atom );
	public final CalcParser.atom_return atom()   {
		CalcParser.atom_return retval = new CalcParser.atom_return();
		retval.start = input.LT(1);

		CommonTree root_0 = null;

		Token DOUBLE20=null;
		Token ID21=null;
		Token char_literal22=null;
		Token char_literal24=null;
		Token string_literal25=null;
		Token char_literal26=null;
		Token char_literal28=null;
		Token string_literal29=null;
		Token char_literal30=null;
		Token char_literal32=null;
		Token string_literal33=null;
		Token char_literal34=null;
		Token char_literal36=null;
		Token string_literal37=null;
		Token char_literal38=null;
		Token char_literal40=null;
		Token string_literal41=null;
		Token char_literal42=null;
		Token char_literal44=null;
		Token char_literal46=null;
		Token char_literal47=null;
		ParserRuleReturnScope expression23 =null;
		ParserRuleReturnScope expression27 =null;
		ParserRuleReturnScope expression31 =null;
		ParserRuleReturnScope expression35 =null;
		ParserRuleReturnScope expression39 =null;
		ParserRuleReturnScope expression43 =null;
		ParserRuleReturnScope expression45 =null;
		ParserRuleReturnScope atom48 =null;

		CommonTree DOUBLE20_tree=null;
		CommonTree ID21_tree=null;
		CommonTree char_literal22_tree=null;
		CommonTree char_literal24_tree=null;
		CommonTree string_literal25_tree=null;
		CommonTree char_literal26_tree=null;
		CommonTree char_literal28_tree=null;
		CommonTree string_literal29_tree=null;
		CommonTree char_literal30_tree=null;
		CommonTree char_literal32_tree=null;
		CommonTree string_literal33_tree=null;
		CommonTree char_literal34_tree=null;
		CommonTree char_literal36_tree=null;
		CommonTree string_literal37_tree=null;
		CommonTree char_literal38_tree=null;
		CommonTree char_literal40_tree=null;
		CommonTree string_literal41_tree=null;
		CommonTree char_literal42_tree=null;
		CommonTree char_literal44_tree=null;
		CommonTree char_literal46_tree=null;
		CommonTree char_literal47_tree=null;

		try {
			// D:\\���뼼��\\antlr\\Calc.g:19:6: ( DOUBLE | ID | '(' ! expression ')' !| 'sin' '(' ! expression ')' !| 'cos' '(' ! expression ')' !| 'tan' '(' ! expression ')' !| 'ln' '(' ! expression ')' !| 'log' '(' ! expression ',' ! expression ')' !| '-' atom )
			int alt8=9;
			switch ( input.LA(1) ) {
			case DOUBLE:
				{
				alt8=1;
				}
				break;
			case ID:
				{
				alt8=2;
				}
				break;
			case 8:
				{
				alt8=3;
				}
				break;
			case 20:
				{
				alt8=4;
				}
				break;
			case 17:
				{
				alt8=5;
				}
				break;
			case 21:
				{
				alt8=6;
				}
				break;
			case 18:
				{
				alt8=7;
				}
				break;
			case 19:
				{
				alt8=8;
				}
				break;
			case 13:
				{
				alt8=9;
				}
				break;
			default:
				NoViableAltException nvae =
					new NoViableAltException("", 8, 0, input);
				throw nvae;
			}
			switch (alt8) {
				case 1 :
					// D:\\���뼼��\\antlr\\Calc.g:19:8: DOUBLE
					{
					root_0 = (CommonTree)adaptor.nil();


					DOUBLE20=(Token)match(input,DOUBLE,FOLLOW_DOUBLE_in_atom156); 
					DOUBLE20_tree = (CommonTree)adaptor.create(DOUBLE20);
					adaptor.addChild(root_0, DOUBLE20_tree);

					}
					break;
				case 2 :
					// D:\\���뼼��\\antlr\\Calc.g:20:3: ID
					{
					root_0 = (CommonTree)adaptor.nil();


					ID21=(Token)match(input,ID,FOLLOW_ID_in_atom160); 
					ID21_tree = (CommonTree)adaptor.create(ID21);
					adaptor.addChild(root_0, ID21_tree);

					}
					break;
				case 3 :
					// D:\\���뼼��\\antlr\\Calc.g:21:3: '(' ! expression ')' !
					{
					root_0 = (CommonTree)adaptor.nil();


					char_literal22=(Token)match(input,8,FOLLOW_8_in_atom164); 
					pushFollow(FOLLOW_expression_in_atom167);
					expression23=expression();
					state._fsp--;

					adaptor.addChild(root_0, expression23.getTree());

					char_literal24=(Token)match(input,9,FOLLOW_9_in_atom169); 
					}
					break;
				case 4 :
					// D:\\���뼼��\\antlr\\Calc.g:22:3: 'sin' '(' ! expression ')' !
					{
					root_0 = (CommonTree)adaptor.nil();


					string_literal25=(Token)match(input,20,FOLLOW_20_in_atom174); 
					string_literal25_tree = (CommonTree)adaptor.create(string_literal25);
					adaptor.addChild(root_0, string_literal25_tree);

					char_literal26=(Token)match(input,8,FOLLOW_8_in_atom176); 
					pushFollow(FOLLOW_expression_in_atom179);
					expression27=expression();
					state._fsp--;

					adaptor.addChild(root_0, expression27.getTree());

					char_literal28=(Token)match(input,9,FOLLOW_9_in_atom181); 
					}
					break;
				case 5 :
					// D:\\���뼼��\\antlr\\Calc.g:23:3: 'cos' '(' ! expression ')' !
					{
					root_0 = (CommonTree)adaptor.nil();


					string_literal29=(Token)match(input,17,FOLLOW_17_in_atom186); 
					string_literal29_tree = (CommonTree)adaptor.create(string_literal29);
					adaptor.addChild(root_0, string_literal29_tree);

					char_literal30=(Token)match(input,8,FOLLOW_8_in_atom188); 
					pushFollow(FOLLOW_expression_in_atom191);
					expression31=expression();
					state._fsp--;

					adaptor.addChild(root_0, expression31.getTree());

					char_literal32=(Token)match(input,9,FOLLOW_9_in_atom193); 
					}
					break;
				case 6 :
					// D:\\���뼼��\\antlr\\Calc.g:24:3: 'tan' '(' ! expression ')' !
					{
					root_0 = (CommonTree)adaptor.nil();


					string_literal33=(Token)match(input,21,FOLLOW_21_in_atom198); 
					string_literal33_tree = (CommonTree)adaptor.create(string_literal33);
					adaptor.addChild(root_0, string_literal33_tree);

					char_literal34=(Token)match(input,8,FOLLOW_8_in_atom200); 
					pushFollow(FOLLOW_expression_in_atom203);
					expression35=expression();
					state._fsp--;

					adaptor.addChild(root_0, expression35.getTree());

					char_literal36=(Token)match(input,9,FOLLOW_9_in_atom205); 
					}
					break;
				case 7 :
					// D:\\���뼼��\\antlr\\Calc.g:25:3: 'ln' '(' ! expression ')' !
					{
					root_0 = (CommonTree)adaptor.nil();


					string_literal37=(Token)match(input,18,FOLLOW_18_in_atom210); 
					string_literal37_tree = (CommonTree)adaptor.create(string_literal37);
					adaptor.addChild(root_0, string_literal37_tree);

					char_literal38=(Token)match(input,8,FOLLOW_8_in_atom212); 
					pushFollow(FOLLOW_expression_in_atom215);
					expression39=expression();
					state._fsp--;

					adaptor.addChild(root_0, expression39.getTree());

					char_literal40=(Token)match(input,9,FOLLOW_9_in_atom217); 
					}
					break;
				case 8 :
					// D:\\���뼼��\\antlr\\Calc.g:26:3: 'log' '(' ! expression ',' ! expression ')' !
					{
					root_0 = (CommonTree)adaptor.nil();


					string_literal41=(Token)match(input,19,FOLLOW_19_in_atom222); 
					string_literal41_tree = (CommonTree)adaptor.create(string_literal41);
					adaptor.addChild(root_0, string_literal41_tree);

					char_literal42=(Token)match(input,8,FOLLOW_8_in_atom224); 
					pushFollow(FOLLOW_expression_in_atom227);
					expression43=expression();
					state._fsp--;

					adaptor.addChild(root_0, expression43.getTree());

					char_literal44=(Token)match(input,12,FOLLOW_12_in_atom229); 
					pushFollow(FOLLOW_expression_in_atom232);
					expression45=expression();
					state._fsp--;

					adaptor.addChild(root_0, expression45.getTree());

					char_literal46=(Token)match(input,9,FOLLOW_9_in_atom234); 
					}
					break;
				case 9 :
					// D:\\���뼼��\\antlr\\Calc.g:27:3: '-' atom
					{
					root_0 = (CommonTree)adaptor.nil();


					char_literal47=(Token)match(input,13,FOLLOW_13_in_atom239); 
					char_literal47_tree = (CommonTree)adaptor.create(char_literal47);
					adaptor.addChild(root_0, char_literal47_tree);

					pushFollow(FOLLOW_atom_in_atom241);
					atom48=atom();
					state._fsp--;

					adaptor.addChild(root_0, atom48.getTree());

					}
					break;

			}
			retval.stop = input.LT(-1);

			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
		}
		return retval;
	}
	// $ANTLR end "atom"

	// Delegated rules



	public static final BitSet FOLLOW_statement_in_program40 = new BitSet(new long[]{0x00000000003E2172L});
	public static final BitSet FOLLOW_expression_in_statement53 = new BitSet(new long[]{0x0000000000000040L});
	public static final BitSet FOLLOW_SEMI_in_statement55 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_ID_in_statement63 = new BitSet(new long[]{0x0000000000008000L});
	public static final BitSet FOLLOW_15_in_statement65 = new BitSet(new long[]{0x00000000003E2130L});
	public static final BitSet FOLLOW_expression_in_statement67 = new BitSet(new long[]{0x0000000000000040L});
	public static final BitSet FOLLOW_SEMI_in_statement69 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_SEMI_in_statement83 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_term_in_expression94 = new BitSet(new long[]{0x0000000000002802L});
	public static final BitSet FOLLOW_11_in_expression98 = new BitSet(new long[]{0x00000000003E2130L});
	public static final BitSet FOLLOW_13_in_expression103 = new BitSet(new long[]{0x00000000003E2130L});
	public static final BitSet FOLLOW_term_in_expression107 = new BitSet(new long[]{0x0000000000002802L});
	public static final BitSet FOLLOW_factor_in_term117 = new BitSet(new long[]{0x0000000000004402L});
	public static final BitSet FOLLOW_10_in_term121 = new BitSet(new long[]{0x00000000003E2130L});
	public static final BitSet FOLLOW_14_in_term126 = new BitSet(new long[]{0x00000000003E2130L});
	public static final BitSet FOLLOW_factor_in_term130 = new BitSet(new long[]{0x0000000000004402L});
	public static final BitSet FOLLOW_atom_in_factor140 = new BitSet(new long[]{0x0000000000010002L});
	public static final BitSet FOLLOW_16_in_factor143 = new BitSet(new long[]{0x00000000003E2130L});
	public static final BitSet FOLLOW_atom_in_factor146 = new BitSet(new long[]{0x0000000000010002L});
	public static final BitSet FOLLOW_DOUBLE_in_atom156 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_ID_in_atom160 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_8_in_atom164 = new BitSet(new long[]{0x00000000003E2130L});
	public static final BitSet FOLLOW_expression_in_atom167 = new BitSet(new long[]{0x0000000000000200L});
	public static final BitSet FOLLOW_9_in_atom169 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_20_in_atom174 = new BitSet(new long[]{0x0000000000000100L});
	public static final BitSet FOLLOW_8_in_atom176 = new BitSet(new long[]{0x00000000003E2130L});
	public static final BitSet FOLLOW_expression_in_atom179 = new BitSet(new long[]{0x0000000000000200L});
	public static final BitSet FOLLOW_9_in_atom181 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_17_in_atom186 = new BitSet(new long[]{0x0000000000000100L});
	public static final BitSet FOLLOW_8_in_atom188 = new BitSet(new long[]{0x00000000003E2130L});
	public static final BitSet FOLLOW_expression_in_atom191 = new BitSet(new long[]{0x0000000000000200L});
	public static final BitSet FOLLOW_9_in_atom193 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_21_in_atom198 = new BitSet(new long[]{0x0000000000000100L});
	public static final BitSet FOLLOW_8_in_atom200 = new BitSet(new long[]{0x00000000003E2130L});
	public static final BitSet FOLLOW_expression_in_atom203 = new BitSet(new long[]{0x0000000000000200L});
	public static final BitSet FOLLOW_9_in_atom205 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_18_in_atom210 = new BitSet(new long[]{0x0000000000000100L});
	public static final BitSet FOLLOW_8_in_atom212 = new BitSet(new long[]{0x00000000003E2130L});
	public static final BitSet FOLLOW_expression_in_atom215 = new BitSet(new long[]{0x0000000000000200L});
	public static final BitSet FOLLOW_9_in_atom217 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_19_in_atom222 = new BitSet(new long[]{0x0000000000000100L});
	public static final BitSet FOLLOW_8_in_atom224 = new BitSet(new long[]{0x00000000003E2130L});
	public static final BitSet FOLLOW_expression_in_atom227 = new BitSet(new long[]{0x0000000000001000L});
	public static final BitSet FOLLOW_12_in_atom229 = new BitSet(new long[]{0x00000000003E2130L});
	public static final BitSet FOLLOW_expression_in_atom232 = new BitSet(new long[]{0x0000000000000200L});
	public static final BitSet FOLLOW_9_in_atom234 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_13_in_atom239 = new BitSet(new long[]{0x00000000003E2130L});
	public static final BitSet FOLLOW_atom_in_atom241 = new BitSet(new long[]{0x0000000000000002L});
}
