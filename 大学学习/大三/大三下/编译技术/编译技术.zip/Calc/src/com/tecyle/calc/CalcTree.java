// $ANTLR 3.5 D:\\���뼼��\\antlr\\CalcTree.g 2013-03-26 15:26:26

package com.tecyle.calc;
import java.util.HashMap;


import org.antlr.runtime.*;
import org.antlr.runtime.tree.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class CalcTree extends TreeParser {
	public static final String[] tokenNames = new String[] {
		"<invalid>", "<EOR>", "<DOWN>", "<UP>", "DOUBLE", "ID", "SEMI", "WS", 
		"'('", "')'", "'*'", "'+'", "','", "'-'", "'/'", "'='", "'^'", "'cos'", 
		"'ln'", "'log'", "'sin'", "'tan'"
	};
	public static final int EOF=-1;
	public static final int T__8=8;
	public static final int T__9=9;
	public static final int T__10=10;
	public static final int T__11=11;
	public static final int T__12=12;
	public static final int T__13=13;
	public static final int T__14=14;
	public static final int T__15=15;
	public static final int T__16=16;
	public static final int T__17=17;
	public static final int T__18=18;
	public static final int T__19=19;
	public static final int T__20=20;
	public static final int T__21=21;
	public static final int DOUBLE=4;
	public static final int ID=5;
	public static final int SEMI=6;
	public static final int WS=7;

	// delegates
	public TreeParser[] getDelegates() {
		return new TreeParser[] {};
	}

	// delegators


	public CalcTree(TreeNodeStream input) {
		this(input, new RecognizerSharedState());
	}
	public CalcTree(TreeNodeStream input, RecognizerSharedState state) {
		super(input, state);
	}

	@Override public String[] getTokenNames() { return CalcTree.tokenNames; }
	@Override public String getGrammarFileName() { return "D:\\���뼼��\\antlr\\CalcTree.g"; }

	 HashMap memory = new HashMap();


	// $ANTLR start "program"
	// D:\\���뼼��\\antlr\\CalcTree.g:12:1: program : ( statement )+ ;
	public final void program()   {
		try {
			// D:\\���뼼��\\antlr\\CalcTree.g:12:9: ( ( statement )+ )
			// D:\\���뼼��\\antlr\\CalcTree.g:12:11: ( statement )+
			{
			// D:\\���뼼��\\antlr\\CalcTree.g:12:11: ( statement )+
			int cnt1=0;
			loop1:
			while (true) {
				int alt1=2;
				int LA1_0 = input.LA(1);
				if ( ((LA1_0 >= DOUBLE && LA1_0 <= ID)||(LA1_0 >= 10 && LA1_0 <= 11)||(LA1_0 >= 13 && LA1_0 <= 21)) ) {
					alt1=1;
				}

				switch (alt1) {
				case 1 :
					// D:\\���뼼��\\antlr\\CalcTree.g:12:11: statement
					{
					pushFollow(FOLLOW_statement_in_program39);
					statement();
					state._fsp--;

					}
					break;

				default :
					if ( cnt1 >= 1 ) break loop1;
					EarlyExitException eee = new EarlyExitException(1, input);
					throw eee;
				}
				cnt1++;
			}

			}

		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "program"



	// $ANTLR start "statement"
	// D:\\���뼼��\\antlr\\CalcTree.g:13:1: statement : ( expression | ^( '=' ID expression ) );
	public final void statement()   {
		CommonTree ID2=null;
		double expression1 =0.0;
		double expression3 =0.0;

		try {
			// D:\\���뼼��\\antlr\\CalcTree.g:14:3: ( expression | ^( '=' ID expression ) )
			int alt2=2;
			int LA2_0 = input.LA(1);
			if ( ((LA2_0 >= DOUBLE && LA2_0 <= ID)||(LA2_0 >= 10 && LA2_0 <= 11)||(LA2_0 >= 13 && LA2_0 <= 14)||(LA2_0 >= 16 && LA2_0 <= 21)) ) {
				alt2=1;
			}
			else if ( (LA2_0==15) ) {
				alt2=2;
			}

			else {
				NoViableAltException nvae =
					new NoViableAltException("", 2, 0, input);
				throw nvae;
			}

			switch (alt2) {
				case 1 :
					// D:\\���뼼��\\antlr\\CalcTree.g:14:3: expression
					{
					pushFollow(FOLLOW_expression_in_statement48);
					expression1=expression();
					state._fsp--;

					System.out.println("Result is :"+expression1);
					}
					break;
				case 2 :
					// D:\\���뼼��\\antlr\\CalcTree.g:15:3: ^( '=' ID expression )
					{
					match(input,15,FOLLOW_15_in_statement55); 
					match(input, Token.DOWN, null); 
					ID2=(CommonTree)match(input,ID,FOLLOW_ID_in_statement57); 
					pushFollow(FOLLOW_expression_in_statement59);
					expression3=expression();
					state._fsp--;

					match(input, Token.UP, null); 

					memory.put((ID2!=null?ID2.getText():null), expression3);
					}
					break;

			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
		}
		finally {
			// do for sure before leaving
		}
	}
	// $ANTLR end "statement"



	// $ANTLR start "expression"
	// D:\\���뼼��\\antlr\\CalcTree.g:17:1: expression returns [double value] : ( ^( '+' a= expression b= expression ) | ^( '-' a= expression b= expression ) | ^( '*' a= expression b= expression ) | ^( '/' a= expression b= expression ) | ^( '^' a= expression b= expression ) | ( 'sin' x= expression ) | ( 'cos' x= expression ) | ( 'tan' x= expression ) | ( 'ln' x= expression ) | ( '-' x= expression ) | ( 'log' a= expression b= expression ) | ID | DOUBLE );
	public final double expression()   {
		double value = 0.0;


		CommonTree ID4=null;
		CommonTree DOUBLE5=null;
		double a =0.0;
		double b =0.0;
		double x =0.0;

		try {
			// D:\\���뼼��\\antlr\\CalcTree.g:18:3: ( ^( '+' a= expression b= expression ) | ^( '-' a= expression b= expression ) | ^( '*' a= expression b= expression ) | ^( '/' a= expression b= expression ) | ^( '^' a= expression b= expression ) | ( 'sin' x= expression ) | ( 'cos' x= expression ) | ( 'tan' x= expression ) | ( 'ln' x= expression ) | ( '-' x= expression ) | ( 'log' a= expression b= expression ) | ID | DOUBLE )
			int alt3=13;
			switch ( input.LA(1) ) {
			case 11:
				{
				alt3=1;
				}
				break;
			case 13:
				{
				int LA3_2 = input.LA(2);
				if ( (LA3_2==DOWN) ) {
					alt3=2;
				}
				else if ( ((LA3_2 >= DOUBLE && LA3_2 <= ID)||(LA3_2 >= 10 && LA3_2 <= 11)||(LA3_2 >= 13 && LA3_2 <= 14)||(LA3_2 >= 16 && LA3_2 <= 21)) ) {
					alt3=10;
				}

				else {
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 3, 2, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case 10:
				{
				alt3=3;
				}
				break;
			case 14:
				{
				alt3=4;
				}
				break;
			case 16:
				{
				alt3=5;
				}
				break;
			case 20:
				{
				alt3=6;
				}
				break;
			case 17:
				{
				alt3=7;
				}
				break;
			case 21:
				{
				alt3=8;
				}
				break;
			case 18:
				{
				alt3=9;
				}
				break;
			case 19:
				{
				alt3=11;
				}
				break;
			case ID:
				{
				alt3=12;
				}
				break;
			case DOUBLE:
				{
				alt3=13;
				}
				break;
			default:
				NoViableAltException nvae =
					new NoViableAltException("", 3, 0, input);
				throw nvae;
			}
			switch (alt3) {
				case 1 :
					// D:\\���뼼��\\antlr\\CalcTree.g:18:3: ^( '+' a= expression b= expression )
					{
					match(input,11,FOLLOW_11_in_expression75); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression79);
					a=expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression83);
					b=expression();
					state._fsp--;

					match(input, Token.UP, null); 

					value = a+b; 
					}
					break;
				case 2 :
					// D:\\���뼼��\\antlr\\CalcTree.g:19:3: ^( '-' a= expression b= expression )
					{
					match(input,13,FOLLOW_13_in_expression91); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression95);
					a=expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression99);
					b=expression();
					state._fsp--;

					match(input, Token.UP, null); 

					value = a-b; 
					}
					break;
				case 3 :
					// D:\\���뼼��\\antlr\\CalcTree.g:20:3: ^( '*' a= expression b= expression )
					{
					match(input,10,FOLLOW_10_in_expression107); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression111);
					a=expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression115);
					b=expression();
					state._fsp--;

					match(input, Token.UP, null); 

					value = a*b; 
					}
					break;
				case 4 :
					// D:\\���뼼��\\antlr\\CalcTree.g:21:3: ^( '/' a= expression b= expression )
					{
					match(input,14,FOLLOW_14_in_expression123); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression127);
					a=expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression131);
					b=expression();
					state._fsp--;

					match(input, Token.UP, null); 

					value = a/b; 
					}
					break;
				case 5 :
					// D:\\���뼼��\\antlr\\CalcTree.g:22:3: ^( '^' a= expression b= expression )
					{
					match(input,16,FOLLOW_16_in_expression139); 
					match(input, Token.DOWN, null); 
					pushFollow(FOLLOW_expression_in_expression143);
					a=expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression147);
					b=expression();
					state._fsp--;

					match(input, Token.UP, null); 

					value = Math.pow(a, b); 
					}
					break;
				case 6 :
					// D:\\���뼼��\\antlr\\CalcTree.g:23:4: ( 'sin' x= expression )
					{
					// D:\\���뼼��\\antlr\\CalcTree.g:23:4: ( 'sin' x= expression )
					// D:\\���뼼��\\antlr\\CalcTree.g:23:5: 'sin' x= expression
					{
					match(input,20,FOLLOW_20_in_expression155); 
					pushFollow(FOLLOW_expression_in_expression159);
					x=expression();
					state._fsp--;

					}

					value = Math.sin(x);
					}
					break;
				case 7 :
					// D:\\���뼼��\\antlr\\CalcTree.g:24:4: ( 'cos' x= expression )
					{
					// D:\\���뼼��\\antlr\\CalcTree.g:24:4: ( 'cos' x= expression )
					// D:\\���뼼��\\antlr\\CalcTree.g:24:5: 'cos' x= expression
					{
					match(input,17,FOLLOW_17_in_expression167); 
					pushFollow(FOLLOW_expression_in_expression171);
					x=expression();
					state._fsp--;

					}

					value = Math.cos(x);
					}
					break;
				case 8 :
					// D:\\���뼼��\\antlr\\CalcTree.g:25:4: ( 'tan' x= expression )
					{
					// D:\\���뼼��\\antlr\\CalcTree.g:25:4: ( 'tan' x= expression )
					// D:\\���뼼��\\antlr\\CalcTree.g:25:5: 'tan' x= expression
					{
					match(input,21,FOLLOW_21_in_expression179); 
					pushFollow(FOLLOW_expression_in_expression183);
					x=expression();
					state._fsp--;

					}

					value = Math.tan(x);
					}
					break;
				case 9 :
					// D:\\���뼼��\\antlr\\CalcTree.g:26:4: ( 'ln' x= expression )
					{
					// D:\\���뼼��\\antlr\\CalcTree.g:26:4: ( 'ln' x= expression )
					// D:\\���뼼��\\antlr\\CalcTree.g:26:5: 'ln' x= expression
					{
					match(input,18,FOLLOW_18_in_expression191); 
					pushFollow(FOLLOW_expression_in_expression195);
					x=expression();
					state._fsp--;

					}

					value = Math.log(x);
					}
					break;
				case 10 :
					// D:\\���뼼��\\antlr\\CalcTree.g:27:4: ( '-' x= expression )
					{
					// D:\\���뼼��\\antlr\\CalcTree.g:27:4: ( '-' x= expression )
					// D:\\���뼼��\\antlr\\CalcTree.g:27:5: '-' x= expression
					{
					match(input,13,FOLLOW_13_in_expression203); 
					pushFollow(FOLLOW_expression_in_expression207);
					x=expression();
					state._fsp--;

					}

					value = -x;
					}
					break;
				case 11 :
					// D:\\���뼼��\\antlr\\CalcTree.g:28:4: ( 'log' a= expression b= expression )
					{
					// D:\\���뼼��\\antlr\\CalcTree.g:28:4: ( 'log' a= expression b= expression )
					// D:\\���뼼��\\antlr\\CalcTree.g:28:5: 'log' a= expression b= expression
					{
					match(input,19,FOLLOW_19_in_expression215); 
					pushFollow(FOLLOW_expression_in_expression219);
					a=expression();
					state._fsp--;

					pushFollow(FOLLOW_expression_in_expression223);
					b=expression();
					state._fsp--;

					}

					value = Math.log(b)/Math.log(a);
					}
					break;
				case 12 :
					// D:\\���뼼��\\antlr\\CalcTree.g:29:3: ID
					{
					ID4=(CommonTree)match(input,ID,FOLLOW_ID_in_expression230); 

					value = 0;
					Double v = (Double)memory.get((ID4!=null?ID4.getText():null));
					if(v != null) value = v;
					else System.err.println("#ff0000 variable " + (ID4!=null?ID4.getText():null));

					}
					break;
				case 13 :
					// D:\\���뼼��\\antlr\\CalcTree.g:36:3: DOUBLE
					{
					DOUBLE5=(CommonTree)match(input,DOUBLE,FOLLOW_DOUBLE_in_expression236); 
					value = Double.parseDouble((DOUBLE5!=null?DOUBLE5.getText():null));
					}
					break;

			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
		}
		finally {
			// do for sure before leaving
		}
		return value;
	}
	// $ANTLR end "expression"

	// Delegated rules



	public static final BitSet FOLLOW_statement_in_program39 = new BitSet(new long[]{0x00000000003FEC32L});
	public static final BitSet FOLLOW_expression_in_statement48 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_15_in_statement55 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_ID_in_statement57 = new BitSet(new long[]{0x00000000003F6C30L});
	public static final BitSet FOLLOW_expression_in_statement59 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_11_in_expression75 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression79 = new BitSet(new long[]{0x00000000003F6C30L});
	public static final BitSet FOLLOW_expression_in_expression83 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_13_in_expression91 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression95 = new BitSet(new long[]{0x00000000003F6C30L});
	public static final BitSet FOLLOW_expression_in_expression99 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_10_in_expression107 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression111 = new BitSet(new long[]{0x00000000003F6C30L});
	public static final BitSet FOLLOW_expression_in_expression115 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_14_in_expression123 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression127 = new BitSet(new long[]{0x00000000003F6C30L});
	public static final BitSet FOLLOW_expression_in_expression131 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_16_in_expression139 = new BitSet(new long[]{0x0000000000000004L});
	public static final BitSet FOLLOW_expression_in_expression143 = new BitSet(new long[]{0x00000000003F6C30L});
	public static final BitSet FOLLOW_expression_in_expression147 = new BitSet(new long[]{0x0000000000000008L});
	public static final BitSet FOLLOW_20_in_expression155 = new BitSet(new long[]{0x00000000003F6C30L});
	public static final BitSet FOLLOW_expression_in_expression159 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_17_in_expression167 = new BitSet(new long[]{0x00000000003F6C30L});
	public static final BitSet FOLLOW_expression_in_expression171 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_21_in_expression179 = new BitSet(new long[]{0x00000000003F6C30L});
	public static final BitSet FOLLOW_expression_in_expression183 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_18_in_expression191 = new BitSet(new long[]{0x00000000003F6C30L});
	public static final BitSet FOLLOW_expression_in_expression195 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_13_in_expression203 = new BitSet(new long[]{0x00000000003F6C30L});
	public static final BitSet FOLLOW_expression_in_expression207 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_19_in_expression215 = new BitSet(new long[]{0x00000000003F6C30L});
	public static final BitSet FOLLOW_expression_in_expression219 = new BitSet(new long[]{0x00000000003F6C30L});
	public static final BitSet FOLLOW_expression_in_expression223 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_ID_in_expression230 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_DOUBLE_in_expression236 = new BitSet(new long[]{0x0000000000000002L});
}
